# Simple program to run binary tree options + graphical design 

#### Menu : 

![alt text](images/menu.png)

#### Graphic : 

![alt text](images/draw.png)

## Authors

- Amir Sabri: [@assaabriiii](https://github.com/assaabriiii) 
- Kimia Keivanloo: [@kimiakeivan](https://github.com/kimiakeivan) 
